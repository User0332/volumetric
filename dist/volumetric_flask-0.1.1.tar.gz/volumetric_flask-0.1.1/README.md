# Volumetric - A Pure-Python Web Framework

Volumetric is an SSR-focused Python web framework built on top of Flask and inspired by [`webpy-framework`](https://github.com/User0332/webpy).

You can install Volumetric from pip using `pip install volumetric-flask`